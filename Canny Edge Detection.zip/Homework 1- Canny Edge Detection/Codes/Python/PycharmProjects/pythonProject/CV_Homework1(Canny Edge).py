#!/usr/bin/env python
# coding: utf-8

# In[58]:


import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
img = cv.imread('starry_night.jpg',0)
width = img.shape[1]
height = img.shape[0]
print(img.shape[0])
print(img.shape[1])
edges = cv.Canny(img,100,170)
plt.figure(figsize = (40,17))
plt.subplot(121),plt.imshow(img,cmap = 'gray')
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(122),plt.imshow(edges,cmap = 'gray', aspect='auto')
plt.title('Edge Image'), plt.xticks([]), plt.yticks([])
plt.show()


# In[ ]:




